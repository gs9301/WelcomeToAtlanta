package com.example.android.welcometotheatlanta;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Set the content of the activity to use the activity main.xml layout file
        setContentView(R.layout.activity_main);

        //Find the view that shows the SunTrustPark activity
        TextView sunTrustPark = (TextView) findViewById(R.id.sunTrustPark);

        //Set a Click Listener on that view
        sunTrustPark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(view.getContext(),
                        R.string.Toast1, Toast.LENGTH_SHORT).show();

                //Create a new intent to open the (@link Sun Trust Park Activity)
                Intent sunTrustParkIntent = new Intent(MainActivity.this, SunTrustParkActivity.class);

                //Start the new activity
                startActivity(sunTrustParkIntent);
            }

        });

        //Find the view that shows the Georgia Aquarium activity
        TextView georgiaAquarium = (TextView) findViewById(R.id.georgiaAquarium);

        //Set a Click Listener on that view
        georgiaAquarium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(view.getContext(),
                        R.string.Toast2, Toast.LENGTH_SHORT).show();

                //Create a new intent to open the (@link Georgia Aquarium Activity)
                Intent georgiaAquarium = new Intent(MainActivity.this, GeorgiaAquariumActivity.class);

                //Start the new activity
                startActivity(georgiaAquarium);
            }

        });

        //Find the view that shows the World of Coca Cola activity
        TextView worldOfCocaCola = (TextView) findViewById(R.id.worldOfCocaCola);

        //Set a Click Listener on that view
        worldOfCocaCola.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(view.getContext(),
                        R.string.Toast3, Toast.LENGTH_SHORT).show();

                //Create a new intent to open the (@link World of Coca Cola Activity)
                Intent worldofCocaCola = new Intent(MainActivity.this, WorldofCocaColaActivity.class);

                //Start the new activity
                startActivity(worldofCocaCola);
            }
        });

        //Find the view that shows the Stone Mountain activity
        TextView stoneMountain = (TextView) findViewById(R.id.stoneMountain);

        //Set a Click Listener on that view
        stoneMountain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(view.getContext(),
                        R.string.Toast4, Toast.LENGTH_SHORT).show();

                //Create a new intent to open the (@link Stone Mountain Activity)
                Intent stoneMountain = new Intent(MainActivity.this, StoneMountainActivity.class);

                //Start the new activity
                startActivity(stoneMountain);
            }

        });

        //Find the view that shows the Botanical Garden activity
        TextView botanicalGarden = (TextView) findViewById(R.id.botanicalGarden);

        //Set a Click Listener on that view
        botanicalGarden.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(view.getContext(),
                        R.string.Toast5, Toast.LENGTH_SHORT).show();

                //Create a new intent to open the (@link Botanical Garden Activity)
                Intent botanicalGarden = new Intent(MainActivity.this, BotanicalGardenActivity.class);

                //Start the new activity
                startActivity(botanicalGarden);
            }

        });
    }}
