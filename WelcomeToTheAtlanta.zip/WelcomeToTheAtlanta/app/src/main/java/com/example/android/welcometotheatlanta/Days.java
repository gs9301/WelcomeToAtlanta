package com.example.android.welcometotheatlanta;

/**
 * represents the hours the location is open
 * it contains a default time open
 */

public class Days {

    /**default day of the week */
    private String mDefaultDays;

    /**Default hours of the day open*/
    private String mWelcomeToTheAtlantaHours;

    /**Image Resource ID for Days*/
    private int mImageResourceID;

    /**get days of the week open*/
    public Days(String defaultDays, String welcomeToTheAtlantaHours) {
        mDefaultDays = defaultDays;
        mWelcomeToTheAtlantaHours = welcomeToTheAtlantaHours;
    }

    public String getmDefaultDays(){
        return mDefaultDays;
    }

    /**get hours open of the days*/
    public String getmWelcomeToAtlantaHours() {
        return mWelcomeToTheAtlantaHours;
    }

    /**Return Image Resource ID of the days*/
    public int getmImageResourceID(){
        return mImageResourceID;
    }

}
