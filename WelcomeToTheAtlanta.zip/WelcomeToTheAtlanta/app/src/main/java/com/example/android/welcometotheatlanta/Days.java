package com.example.android.welcometotheatlanta;

/**
 * represents the hours the location is open
 * it contains a default time open
 */

public class Days {

    /**default day of the week
    */
    private String mDefaultDays;

    /**Default hours of the day open*/
    private String mWelcomeToTheAtlantaHours;

    public Days(String defaultDays,String welcomeToTheAtlantaHours) {
        mDefaultDays = defaultDays;
        mWelcomeToTheAtlantaHours = defaultDays;
    }

    /**
     * get days of the week open
     */
    public String getDefaultDays() {
        return mDefaultDays;
    }

    /**
     * get hours open of the days
     */
    public String getWelcomeToAtlantaHours() {

        return mWelcomeToTheAtlantaHours;
    }

}
