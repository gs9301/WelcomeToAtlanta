package com.example.android.welcometotheatlanta;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class StoneMountainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stone_mountain);

        //Create an array of days
        ArrayList<com.example.android.welcometotheatlanta.Days> days = new ArrayList<com.example.android.welcometotheatlanta.Days>();
        days.add(new com.example.android.welcometotheatlanta.Days(getString(R.string.Mon4),getString(R.string.Hrs_Mon4)));
        days.add(new com.example.android.welcometotheatlanta.Days(getString(R.string.Tue4),getString(R.string.Hrs_Tue4)));
        days.add(new com.example.android.welcometotheatlanta.Days(getString(R.string.Wed4),getString(R.string.Hrs_Wed4)));
        days.add(new com.example.android.welcometotheatlanta.Days(getString(R.string.Thur4),getString(R.string.Hrs_Thur4)));
        days.add(new com.example.android.welcometotheatlanta.Days(getString(R.string.Fri4),getString(R.string.Hrs_Fri4)));
        days.add(new com.example.android.welcometotheatlanta.Days(getString(R.string.Sat4),getString(R.string.Hrs_Sat4)));
        days.add(new com.example.android.welcometotheatlanta.Days(getString(R.string.Sun4),getString(R.string.Hrs_Sun4)));


        // Create an {@link ArrayAdapter}, whose data source is a list of Strings. The
        // adapter knows how to create layouts for each item in the list, using the
        // simple_list_item_1.xml layout resource defined in the Android framework.
        // This list item layout contains a single {@link TextView}, which the adapter will set to
        // display a single word.
        com.example.android.welcometotheatlanta.DaysAdapter adapter =
                new com.example.android.welcometotheatlanta.DaysAdapter(this,days);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // activity_numbers.xml layout file.
        ListView listView = (ListView) findViewById(R.id.list);

        // Make the {@link ListView} use the {@link ArrayAdapter} we created above, so that the
        // {@link ListView} will display list items for each word in the list of words.
        // Do this by calling the setAdapter method on the {@link ListView} object and pass in
        // 1 argument, which is the {@link ArrayAdapter} with the variable name itemsAdapter.
        listView.setAdapter(adapter);

    }
}
