package com.example.android.welcometoatlanta;

/**
 * {@Link Days} represents the hours the location is open
 * it contains a default time open
 */

public class Days {

    /**Default days of the week open*/
    private String mDefaultDays;

    /**Default hours of the day open*/
    private String mWelcomeToAtlantaHours;

    /**Image Resource ID for Days*/
    private int mImageResourceID;

    /**
     * Create a new Days Object.
     * @param defaultDays
     * @param welcomeToAtlantaHours
     * @param imageResourceID is the drawable resouce id for the image
     */

    public Days(String defaultDays,String welcomeToAtlantaHours, int imageResourceID){
        mDefaultDays = defaultDays;
        mWelcomeToAtlantaHours = welcomeToAtlantaHours;
        mImageResourceID = mImageResourceID ;
    }

    /**
     * get days of the week open
     */
    public String getmDefaultDays() {
        return mDefaultDays;
    }

    /**
     * get hours open of the days
     */
    public String getmWelcomeToAtlantaHours() {
        return mWelcomeToAtlantaHours;
    }

    /**Return Image Resource ID of Days
     *
     */
    public int getImageResourceID() {
        return mImageResourceID;
    }
}


